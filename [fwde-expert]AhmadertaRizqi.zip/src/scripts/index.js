import 'regenerator-runtime'; /* for async await transpile */
import './views';
import './utilities';

import '../styles/index.css';

console.log('Hello Coders! :)');